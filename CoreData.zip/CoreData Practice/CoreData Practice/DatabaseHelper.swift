//
//  DatabaseHelper.swift
//  CoreData Practice
//
//  Created by agile14 on 30/07/22.
//

import UIKit
import CoreData

class DatabaseHelper {
    
    static var shareInstance = DatabaseHelper()
    
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    func saveStudentData(_ dict: [String: String]) {
        
        let student = NSEntityDescription.insertNewObject(forEntityName: "Student", into: context) as! Student
        student.fullName = dict["fullName"]
        student.email = dict["email"]
        student.gender = dict["gender"]
        student.studentClass = dict["class"]
        student.password = dict["password"]
        
        do {
            try context.save()
            print(dict)
            print("Data is saved succesfully")
        } catch {
            print("Data is not saved")
        }
        
    }
    
    func getStudentData(entityName: String) -> [NSManagedObject] {
        var student = [NSManagedObject]()
        let fetchReq = NSFetchRequest<NSManagedObject>.init(entityName: entityName)
        do {
            student = try context.fetch(fetchReq)
        } catch {
            print("Students data is not found!")
        }
        
        return student
    }
    
}
