//
//  ViewController.swift
//  CoreData Practice
//
//  Created by agile14 on 30/07/22.
//

import UIKit
import DropDown

class ViewController: UIViewController {
    
    @IBOutlet weak var nameField: UITextField!
    @IBOutlet weak var classField: UITextField!
    @IBOutlet weak var emailField: UITextField!
    @IBOutlet weak var genderField: UITextField!
    @IBOutlet weak var passwordField: UITextField!
    @IBOutlet weak var confPassField: UITextField!
    
    var arrayOfStudent = [Student]()
    var dataHelper = DatabaseHelper()
    
    
    var classDropdown = DropDown()
    var genderDropdown = DropDown()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        classDropdown.anchorView = classField
        genderDropdown.anchorView = genderField
        
        classDropdown.dataSource = ["Std 8", "Std 9", "Std 10", "Std 11 Science", "Std 12 science", "Std 11 commerce","Std 12 commerce"]
        genderDropdown.dataSource = ["Male", "Female"]
        
        classDropdown.selectionAction = { (index: Int, item: String) in
            self.classField.text = item
        }
        genderDropdown.selectionAction = { (index: Int, item: String) in
            self.genderField.text = item
        }

    }

    @IBAction func submitBtnAction(_ sender: UIButton) {
        
        let name = nameField.text!
        let studentClass = classField.text!
        let email = emailField.text!
        let gender = genderField.text!
        let password = passwordField.text!
        let confPassword = confPassField.text!
        
        if name != "" && studentClass != "" && email != "" && gender != "" {
            
            if isValidEmail(email) {
                print("Email is Valid")
                if isValidPassword(password) {
                    print("password is strong")
                    if password == confPassword {
                        print("Passwords Match")
                        
                        let dict = ["fullName": name, "gender": gender, "email": email, "class": studentClass, "password": password]
                        
                        dataHelper.saveStudentData(dict)
                        self.navigationController?.popViewController(animated: true)
                        
                    } else {
                        print("Passwords do not match")
                    }
                } else {
                    print("Your password is weak")
                }
            } else {
                print("Email is invalid")
            }
        } else {
            print("One of the fields is empty")
        }
        
       
        
        
        
       
    }
    
    
    @IBAction func showClassOptions(_ sender: UIButton) {
        if sender.currentTitle == "class" {
            classDropdown.show()
        } else {
            genderDropdown.show()
        }
        
    }
    
}

func isValidEmail(_ email: String) -> Bool {
    let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
    let emailPred = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
    return emailPred.evaluate(with: email)
}

func isValidPassword(_ password: String) -> Bool {
    let passwordRegEx = "^(?=.*[A-Za-z])(?=.*\\d)[A-Za-z\\d]{8,}$"
    let passwordPred = NSPredicate(format:"SELF MATCHES %@", passwordRegEx)
    return passwordPred.evaluate(with: password)
}

