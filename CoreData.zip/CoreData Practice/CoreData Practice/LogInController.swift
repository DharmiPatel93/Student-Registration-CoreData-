//
//  LogInController.swift
//  CoreData Practice
//
//  Created by agile14 on 02/08/22.
//

import UIKit

class LogInController: UIViewController {
    
    var dataHelper = DatabaseHelper()
    var studentData: [Student] = []
    
    @IBOutlet weak var notFoundLbl: UILabel!
    @IBOutlet weak var emailField: UITextField!
    @IBOutlet weak var passField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        notFoundLbl.isHidden = true
        
        getData()
    }
    
    func getData() {
        studentData = dataHelper.getStudentData(entityName: "Student") as! [Student]
    }
    

    @IBAction func loginAction(_ sender: UIButton) {
        let userEnteredEmail = emailField.text!
        let userEnteredPassword = passField.text!
        
        for student in studentData {
            if userEnteredEmail == student.email {
                if userEnteredPassword == student.password {
                    
                    let vc = self.storyboard?.instantiateViewController(withIdentifier: "StudentsListController") as! StudentsListController
                    
                    self.navigationController?.pushViewController(vc, animated: true)
                }
            }
        }
        
        notFoundLbl.isHidden = false
    }
    

}
