//
//  DetailsController.swift
//  CoreData Practice
//
//  Created by agile14 on 02/08/22.
//

import UIKit
import ImageLoader
import Alamofire

class DetailsController: UIViewController {
    
    var name = ""
    var sClass = ""
    var email = ""
    var gender = ""
    
    @IBOutlet weak var image: UIImageView!
    @IBOutlet weak var nameLbl: UILabel!
    @IBOutlet weak var classLbl: UILabel!
    @IBOutlet weak var emailLbl: UILabel!
    @IBOutlet weak var genderLbl: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        nameLbl.text = name
        classLbl.text = sClass
        emailLbl.text = email
        genderLbl.text = gender
        
        var alamofire = Alamofire()
        AF.request(
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
