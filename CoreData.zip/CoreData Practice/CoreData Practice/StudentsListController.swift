//
//  StudentsListController.swift
//  CoreData Practice
//
//  Created by agile14 on 02/08/22.
//

import UIKit

class StudentsListController: UIViewController {
    
    var dataHelper = DatabaseHelper()
    var studentData: [Student] = []
    
    @IBOutlet weak var tableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        tableView.dataSource = self
        tableView.delegate = self
        
        tableView.register(UINib(nibName: "TableViewCell", bundle: nil), forCellReuseIdentifier: "detailsCell")
        
        getData()
    }
    
    func getData() {
        studentData = dataHelper.getStudentData(entityName: "Student") as! [Student]
    }
    
}

extension StudentsListController: UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return studentData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let row = indexPath.row
        let cell = tableView.dequeueReusableCell(withIdentifier: "detailsCell", for: indexPath) as! TableViewCell
        
        cell.fullName.text = studentData[row].fullName
        cell.classLbl.text = studentData[row].studentClass
        cell.gender.text = studentData[row].gender
        cell.email.text = studentData[row].email
        
        return cell
    }
    
    
    
}

extension StudentsListController: UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let row = indexPath.row
        
        let vc = storyboard?.instantiateViewController(withIdentifier: "DetailsController") as! DetailsController
        
        vc.name = studentData[row].fullName!
        vc.sClass = studentData[row].studentClass!
        vc.email = studentData[row].email!
        vc.gender = studentData[row].gender!
        
        navigationController?.pushViewController(vc, animated: true)
    }
}


