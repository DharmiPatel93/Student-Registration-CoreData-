//
//  Student+CoreDataProperties.swift
//  CoreData Practice
//
//  Created by agile14 on 30/07/22.
//
//

import Foundation
import CoreData


extension Student {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Student> {
        return NSFetchRequest<Student>(entityName: "Student")
    }

    @NSManaged public var fullName: String?
    @NSManaged public var studentClass: String?
    @NSManaged public var email: String?
    @NSManaged public var gender: String?
    @NSManaged public var password: String?
    @NSManaged public var confirmPassword: String?

}

extension Student : Identifiable {

}
