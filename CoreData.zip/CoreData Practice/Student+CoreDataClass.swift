//
//  Student+CoreDataClass.swift
//  CoreData Practice
//
//  Created by agile14 on 30/07/22.
//
//

import Foundation
import CoreData

@objc(Student)
public class Student: NSManagedObject {

}
